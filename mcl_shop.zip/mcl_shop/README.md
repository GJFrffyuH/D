# mcl_shop

Bloc **Shop** pour Mineclonia. Monnaie : l'émeraude (`mcl_core:emerald`).

## Fonctionnement
- Le bloc appartient à celui qui le pose. Seul le propriétaire (ou un admin avec le privilège `server`) peut le casser. Le stock et les gains sont lâchés à la destruction.
- **4 articles** par bloc, toujours.

### Propriétaire (clic droit)
- **Articles** : dans chaque case, pose 1 ou plusieurs exemplaires de l'objet. Le nombre posé = quantité vendue par achat (l'objet posé n'est pas consommé). Entre le prix en émeraudes et clique sur *Enregistrer les prix*. *Vider* retire l'article (le stock est rendu).
- **Stock** : choisis l'article, puis place les objets à vendre dans ses piles de stock (seul l'objet de l'article est accepté).
- **Gains & niveau** : récupère les émeraudes encaissées, vois le niveau d'amélioration.

### Acheteur (clic droit)
- Page d'achat : objet, quantité, prix, stock, bouton *Acheter*. Les émeraudes sont prélevées directement dans l'inventaire.

## Améliorations de stock
Clic droit sur le shop avec l'objet en main (dans l'ordre) :

| Niveau | Piles de stock / article |
|--------|--------------------------|
| 0 (base) | 1 (4 piles au total) |
| I   | 2 |
| II  | 4 |
| III | 8 |

## Crafts
- **Shop** : émeraude (coins haut), planches, lingot de fer au centre, planches en bas.
- **Amélioration I** : 4 lingots de fer (coins) + 4 émeraudes + 1 planche au centre.
- **Amélioration II** : 4 lingots d'or (coins) + 4 émeraudes + Amélioration I au centre.
- **Amélioration III** : 4 diamants (coins) + 4 blocs d'émeraude + Amélioration II au centre.
