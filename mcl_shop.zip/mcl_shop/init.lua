-- mcl_shop : bloc boutique pour Mineclonia
-- * 4 articles par bloc, le bloc appartient à celui qui l'a posé
-- * Propriétaire : page de paramétrage (objet, quantité, prix) + page stock + gains
-- * Autres joueurs : page d'achat, émeraudes prélevées directement dans l'inventaire
-- * Améliorations : plus de piles de stock par article (la vente reste à 4 articles)

local modname = minetest.get_current_modname()
local esc = minetest.formspec_escape
local has_fs = minetest.get_modpath("mcl_formspec") ~= nil

local EMERALD     = "mcl_core:emerald"
local N_ARTICLES  = 4
local LANE        = 8                    -- emplacements max de stock par article
local STACKS      = {[0] = 1, 2, 4, 8}   -- piles de stock par article selon le niveau (0 à 3)
local MAX_LEVEL   = 3
local MAX_PRICE   = 9999
local FORMNAME    = modname .. ":shop"
local ROMAN       = {"I", "II", "III"}

local contexts = {}

---------------------------------------------------------------------
-- Utilitaires
---------------------------------------------------------------------

local function say(name, msg)
	minetest.chat_send_player(name, minetest.colorize("#2ecc71", "[Shop] ") .. msg)
end

local function slotbg(x, y, w, h)
	if has_fs and mcl_formspec and mcl_formspec.get_itemslot_bg_v4 then
		return mcl_formspec.get_itemslot_bg_v4(x, y, w, h)
	end
	return ""
end

local function is_owner(pos, player)
	if not player then return false end
	local name = player:get_player_name()
	if minetest.get_meta(pos):get_string("owner") == name then return true end
	return minetest.check_player_privs(name, {server = true})
end

local function get_level(meta)
	return math.max(0, math.min(meta:get_int("level"), MAX_LEVEL))
end

local function lane_slots(level)
	return STACKS[level] or 1
end

local function lane_of(index)
	return math.floor((index - 1) / LANE) + 1, (index - 1) % LANE + 1
end

local function item_desc(name)
	local def = minetest.registered_items[name]
	local d = def and (def.short_description or def.description) or name
	d = minetest.strip_colors(d):match("^[^\n]*") or name
	if d == "" then d = name end
	if #d > 20 then d = d:sub(1, 18) .. ".." end
	return d
end

local function get_article(meta, i)
	local st = meta:get_inventory():get_stack("sale", i)
	if st:is_empty() then return nil end
	return {
		name  = st:get_name(),
		count = st:get_count(),
		price = meta:get_int("price" .. i),
	}
end

local function lane_count(meta, lane, name)
	local inv = meta:get_inventory()
	local total = 0
	for k = (lane - 1) * LANE + 1, lane * LANE do
		local st = inv:get_stack("stock", k)
		if st:get_name() == name then total = total + st:get_count() end
	end
	return total
end

local function count_emeralds(inv)
	local n = 0
	for _, st in ipairs(inv:get_list("main") or {}) do
		if st:get_name() == EMERALD then n = n + st:get_count() end
	end
	return n
end

local function can_stock(pos, index, stack)
	local meta = minetest.get_meta(pos)
	local lane, off = lane_of(index)
	if lane < 1 or lane > N_ARTICLES then return false end
	if off > lane_slots(get_level(meta)) then return false end
	local sale = meta:get_inventory():get_stack("sale", lane)
	return (not sale:is_empty()) and stack:get_name() == sale:get_name()
end

-- Rend le stock d'un article au joueur (ou le lâche au sol)
local function flush_lane(pos, lane, player)
	local inv = minetest.get_meta(pos):get_inventory()
	local pinv = player and player:get_inventory()
	for k = (lane - 1) * LANE + 1, lane * LANE do
		local st = inv:get_stack("stock", k)
		if not st:is_empty() then
			inv:set_stack("stock", k, ItemStack(""))
			if pinv then st = pinv:add_item("main", st) end
			if not st:is_empty() then
				minetest.add_item(vector.add(pos, {x = 0, y = 1, z = 0}), st)
			end
		end
	end
end

---------------------------------------------------------------------
-- Formspecs
---------------------------------------------------------------------

local function player_inv(y)
	return table.concat({
		"list[current_player;main;0.375,", y, ";9,3;9]", slotbg(0.375, y, 9, 3),
		"list[current_player;main;0.375,", y + 3.75, ";9,1;]", slotbg(0.375, y + 3.75, 9, 1),
	})
end

local function buyer_formspec(pos, name)
	local meta = minetest.get_meta(pos)
	local owner = meta:get_string("owner")
	local pinv = minetest.get_player_by_name(name):get_inventory()
	local fs = {
		"formspec_version[4]", "size[11.75,6.4]",
		"label[0.375,0.5;", esc("Boutique de " .. owner), "]",
		"label[7.6,0.5;", esc("Tes émeraudes : " .. count_emeralds(pinv)), "]",
	}
	for i = 1, N_ARTICLES do
		local x = 0.375 + (i - 1) * 2.75
		fs[#fs + 1] = "box[" .. x .. ",1.0;2.5,4.9;#00000040]"
		local art = get_article(meta, i)
		if not art or art.price <= 0 then
			fs[#fs + 1] = "label[" .. (x + 0.45) .. ",3.4;Emplacement vide]"
		else
			local stock = lane_count(meta, i, art.name)
			fs[#fs + 1] = "item_image[" .. (x + 0.75) .. ",1.2;1,1;" .. art.name .. "]"
			fs[#fs + 1] = "label[" .. (x + 0.15) .. ",2.6;" .. esc(item_desc(art.name)) .. "]"
			fs[#fs + 1] = "label[" .. (x + 0.15) .. ",3.05;" .. esc("Quantité : " .. art.count) .. "]"
			fs[#fs + 1] = "item_image[" .. (x + 0.15) .. ",3.35;0.5,0.5;" .. EMERALD .. "]"
			fs[#fs + 1] = "label[" .. (x + 0.75) .. ",3.6;" .. esc("Prix : " .. art.price) .. "]"
			fs[#fs + 1] = "label[" .. (x + 0.15) .. ",4.2;" .. esc("Stock : " .. stock) .. "]"
			if stock >= art.count then
				fs[#fs + 1] = "button[" .. (x + 0.15) .. ",4.85;2.2,0.8;buy" .. i .. ";Acheter]"
			else
				fs[#fs + 1] = "label[" .. (x + 0.35) .. ",5.25;Rupture de stock]"
			end
		end
	end
	return table.concat(fs)
end

local function tabbar(cur)
	return table.concat({
		"style[tab_", cur, ";bgcolor=#2e8b57]",
		"button[0.375,0.25;3.0,0.7;tab_articles;Articles]",
		"button[3.5,0.25;3.0,0.7;tab_stock;Stock]",
		"button[6.625,0.25;3.0,0.7;tab_info;Gains & niveau]",
	})
end

local function owner_formspec(pos, ctx)
	local meta = minetest.get_meta(pos)
	local inv = meta:get_inventory()
	local level = get_level(meta)
	local loc = "nodemeta:" .. pos.x .. "," .. pos.y .. "," .. pos.z
	local tab = ctx.tab or "articles"
	local fs = {"formspec_version[4]"}

	if tab == "articles" then
		fs[#fs + 1] = "size[11.75,7.0]"
		fs[#fs + 1] = tabbar("articles")
		fs[#fs + 1] = "label[0.375,1.25;Pose 1 ou plusieurs exemplaires de l'objet : leur nombre = quantité par vente.]"
		for i = 1, N_ARTICLES do
			local x = 0.375 + (i - 1) * 2.75
			local st = inv:get_stack("sale", i)
			fs[#fs + 1] = "box[" .. x .. ",1.6;2.5,4.3;#00000040]"
			fs[#fs + 1] = "label[" .. (x + 0.15) .. ",1.9;Article " .. i .. "]"
			fs[#fs + 1] = "list[" .. loc .. ";sale;" .. (x + 0.75) .. ",2.2;1,1;" .. (i - 1) .. "]"
			fs[#fs + 1] = slotbg(x + 0.75, 2.2, 1, 1)
			local q = st:is_empty() and "-" or tostring(st:get_count())
			fs[#fs + 1] = "label[" .. (x + 0.15) .. ",3.6;" .. esc("Quantité : " .. q) .. "]"
			fs[#fs + 1] = "field[" .. (x + 0.15) .. ",4.35;2.2,0.7;price" .. i .. ";Prix (émeraudes);" ..
				meta:get_int("price" .. i) .. "]"
			fs[#fs + 1] = "button[" .. (x + 0.15) .. ",5.15;2.2,0.6;clear" .. i .. ";Vider]"
		end
		fs[#fs + 1] = "button[4.0,6.1;3.75,0.7;save;Enregistrer les prix]"
		fs[#fs + 1] = "field_close_on_enter[price1;false]field_close_on_enter[price2;false]" ..
			"field_close_on_enter[price3;false]field_close_on_enter[price4;false]"

	elseif tab == "stock" then
		local lane = ctx.lane or 1
		local slots = lane_slots(level)
		local art = get_article(meta, lane)
		fs[#fs + 1] = "size[11.75,9.0]"
		fs[#fs + 1] = tabbar("stock")
		fs[#fs + 1] = "style[lane" .. lane .. ";bgcolor=#2e8b57]"
		for i = 1, N_ARTICLES do
			local x = 0.375 + (i - 1) * 2.75
			fs[#fs + 1] = "button[" .. x .. ",1.1;2.5,0.6;lane" .. i .. ";Article " .. i .. "]"
		end
		if art then
			fs[#fs + 1] = "label[0.375,2.15;" .. esc("Article " .. lane .. " : " .. item_desc(art.name) ..
				"  -  en stock : " .. lane_count(meta, lane, art.name) ..
				"  (" .. slots .. " pile(s) max)") .. "]"
			fs[#fs + 1] = "list[" .. loc .. ";stock;0.375,2.5;" .. slots .. ",1;" .. ((lane - 1) * LANE) .. "]"
			fs[#fs + 1] = slotbg(0.375, 2.5, slots, 1)
		else
			fs[#fs + 1] = "label[0.375,2.5;" .. esc("Définis d'abord l'objet de l'article " .. lane ..
				" dans l'onglet Articles.") .. "]"
		end
		fs[#fs + 1] = player_inv(4.1)
		fs[#fs + 1] = "listring[" .. loc .. ";stock]listring[current_player;main]"

	else -- info
		local earn = meta:get_int("earnings")
		fs[#fs + 1] = "size[11.75,6.2]"
		fs[#fs + 1] = tabbar("info")
		fs[#fs + 1] = "item_image[0.375,1.3;0.8,0.8;" .. EMERALD .. "]"
		fs[#fs + 1] = "label[1.4,1.7;" .. esc("Gains en attente : " .. earn .. " émeraude(s)") .. "]"
		if earn > 0 then
			fs[#fs + 1] = "button[0.375,2.4;4,0.7;collect;Retirer les gains]"
		end
		fs[#fs + 1] = "label[0.375,3.6;" .. esc("Niveau d'amélioration : " .. level .. " / " .. MAX_LEVEL ..
			"   (" .. lane_slots(level) .. " pile(s) de stock par article)") .. "]"
		if level < MAX_LEVEL then
			fs[#fs + 1] = "label[0.375,4.2;" .. esc("Prochaine : Amélioration de shop " .. ROMAN[level + 1] ..
				" (" .. lane_slots(level + 1) .. " piles par article)") .. "]"
			fs[#fs + 1] = "label[0.375,4.75;Fais un clic droit sur le shop avec l'amélioration en main.]"
		else
			fs[#fs + 1] = "label[0.375,4.2;Niveau maximum atteint.]"
		end
	end
	return table.concat(fs)
end

local function show(player, pos)
	local name = player:get_player_name()
	local old = contexts[name]
	local ctx = {pos = pos}
	if old and vector.equals(old.pos, pos) then ctx.tab, ctx.lane = old.tab, old.lane end
	contexts[name] = ctx
	local fs
	if is_owner(pos, player) then
		ctx.tab = ctx.tab or "articles"
		ctx.lane = ctx.lane or 1
		fs = owner_formspec(pos, ctx)
	else
		fs = buyer_formspec(pos, name)
	end
	minetest.show_formspec(name, FORMNAME, fs)
end

local function refresh_later(player, pos)
	local name = player:get_player_name()
	minetest.after(0, function()
		local p = minetest.get_player_by_name(name)
		local ctx = contexts[name]
		if p and ctx and vector.equals(ctx.pos, pos) then show(p, pos) end
	end)
end

---------------------------------------------------------------------
-- Logique de vente
---------------------------------------------------------------------

local function set_sale(pos, index, stack, player)
	local meta = minetest.get_meta(pos)
	local inv = meta:get_inventory()
	local old = inv:get_stack("sale", index)
	local new = ItemStack(stack:get_name())
	if new:is_empty() then return end
	new:set_count(math.max(1, math.min(stack:get_count(), stack:get_stack_max())))
	if old:get_name() ~= new:get_name() then
		flush_lane(pos, index, player)
	end
	inv:set_stack("sale", index, new)
	refresh_later(player, pos)
end

local function clear_sale(pos, index, player)
	local meta = minetest.get_meta(pos)
	flush_lane(pos, index, player)
	meta:get_inventory():set_stack("sale", index, ItemStack(""))
	meta:set_int("price" .. index, 0)
	refresh_later(player, pos)
end

local function do_buy(pos, buyer, i)
	local name = buyer:get_player_name()
	local meta = minetest.get_meta(pos)
	local art = get_article(meta, i)
	if not art or art.price <= 0 then
		return say(name, "Cet article n'est pas à vendre.")
	end
	local pinv = buyer:get_inventory()
	local cost = ItemStack(EMERALD .. " " .. art.price)
	if not pinv:contains_item("main", cost) then
		return say(name, "Il te faut " .. art.price .. " émeraude(s) dans ton inventaire.")
	end

	-- on prépare le prélèvement dans le stock
	local sinv = meta:get_inventory()
	local need, plan = art.count, {}
	for k = (i - 1) * LANE + 1, i * LANE do
		local st = sinv:get_stack("stock", k)
		if need > 0 and st:get_name() == art.name then
			local take = math.min(need, st:get_count())
			plan[#plan + 1] = {k = k, take = take, piece = st:peek_item(take)}
			need = need - take
		end
	end
	if need > 0 then return say(name, "Rupture de stock pour cet article.") end

	-- paiement direct dans l'inventaire de l'acheteur
	pinv:remove_item("main", cost)
	for _, p in ipairs(plan) do
		local st = sinv:get_stack("stock", p.k)
		st:take_item(p.take)
		sinv:set_stack("stock", p.k, st)
		local left = pinv:add_item("main", p.piece)
		if not left:is_empty() then minetest.add_item(buyer:get_pos(), left) end
	end
	meta:set_int("earnings", meta:get_int("earnings") + art.price)

	say(name, "Achat : " .. art.count .. " x " .. item_desc(art.name) .. " pour " .. art.price .. " émeraude(s).")
	local owner = meta:get_string("owner")
	if owner ~= name and minetest.get_player_by_name(owner) then
		say(owner, name .. " t'a acheté " .. art.count .. " x " .. item_desc(art.name) ..
			" (+" .. art.price .. " émeraudes).")
	end
end

minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= FORMNAME then return false end
	local name = player:get_player_name()
	local ctx = contexts[name]
	if not ctx then return true end
	if fields.quit then contexts[name] = nil return true end

	local pos = ctx.pos
	if minetest.get_node(pos).name ~= modname .. ":shop"
			or vector.distance(player:get_pos(), pos) > 8 then
		contexts[name] = nil
		return true
	end
	local meta = minetest.get_meta(pos)

	if is_owner(pos, player) then
		-- sauvegarde des prix à chaque envoi de la page Articles
		for i = 1, N_ARTICLES do
			local v = fields["price" .. i]
			if v then
				local n = math.floor(tonumber(v) or 0)
				meta:set_int("price" .. i, math.max(0, math.min(n, MAX_PRICE)))
			end
		end
		if fields.tab_articles then ctx.tab = "articles" end
		if fields.tab_stock then ctx.tab = "stock" end
		if fields.tab_info then ctx.tab = "info" end
		for i = 1, N_ARTICLES do
			if fields["lane" .. i] then ctx.lane = i end
			if fields["clear" .. i] then clear_sale(pos, i, player) end
		end
		if fields.collect then
			local e = meta:get_int("earnings")
			local pinv = player:get_inventory()
			while e > 0 do
				local n = math.min(e, 64)
				local left = pinv:add_item("main", ItemStack(EMERALD .. " " .. n))
				if not left:is_empty() then
					-- inventaire plein : on s'arrête, le reste reste en attente
					e = e - n + left:get_count()
					break
				end
				e = e - n
			end
			meta:set_int("earnings", e)
		end
	else
		for i = 1, N_ARTICLES do
			if fields["buy" .. i] then do_buy(pos, player, i) end
		end
	end
	show(player, pos)
	return true
end)

minetest.register_on_leaveplayer(function(player)
	contexts[player:get_player_name()] = nil
end)

---------------------------------------------------------------------
-- Bloc Shop
---------------------------------------------------------------------

local UPGRADES = {}
for tier = 1, MAX_LEVEL do UPGRADES[modname .. ":upgrade_" .. tier] = tier end

minetest.register_node(modname .. ":shop", {
	description = "Shop",
	_tt_help = "Boutique personnelle : 4 articles vendus contre des émeraudes",
	tiles = {
		"mcl_shop_top.png", "mcl_shop_top.png",
		"mcl_shop_side.png", "mcl_shop_side.png",
		"mcl_shop_side.png", "mcl_shop_front.png",
	},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {handy = 1, axey = 1, deco_block = 1, unmovable_by_piston = 1},
	sounds = mcl_sounds.node_sound_wood_defaults(),
	_mcl_blast_resistance = 1200,
	_mcl_hardness = 2,

	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		inv:set_size("sale", N_ARTICLES)
		inv:set_size("stock", N_ARTICLES * LANE)
		meta:set_int("level", 0)
		meta:set_int("earnings", 0)
		meta:set_string("infotext", "Boutique")
	end,

	after_place_node = function(pos, placer)
		if not placer then return end
		local name = placer:get_player_name()
		local meta = minetest.get_meta(pos)
		meta:set_string("owner", name)
		meta:set_string("infotext", "Boutique de " .. name)
	end,

	can_dig = function(pos, player)
		return is_owner(pos, player)
	end,

	on_destruct = function(pos)
		local meta = minetest.get_meta(pos)
		local inv = meta:get_inventory()
		for k = 1, inv:get_size("stock") do
			local st = inv:get_stack("stock", k)
			if not st:is_empty() then minetest.add_item(pos, st) end
		end
		local e = meta:get_int("earnings")
		while e > 0 do
			local n = math.min(e, 64)
			minetest.add_item(pos, ItemStack(EMERALD .. " " .. n))
			e = e - n
		end
	end,

	on_rightclick = function(pos, node, clicker, itemstack)
		if not clicker or not clicker:is_player() then return itemstack end
		local name = clicker:get_player_name()
		local tier = UPGRADES[itemstack:get_name()]
		if tier then
			local meta = minetest.get_meta(pos)
			if not is_owner(pos, clicker) then
				say(name, "Seul le propriétaire peut améliorer ce shop.")
			elseif get_level(meta) + 1 ~= tier then
				if get_level(meta) >= MAX_LEVEL then
					say(name, "Ce shop est déjà au niveau maximum.")
				else
					say(name, "Il faut d'abord l'Amélioration de shop " .. ROMAN[get_level(meta) + 1] .. ".")
				end
			else
				meta:set_int("level", tier)
				if not minetest.is_creative_enabled(name) then itemstack:take_item() end
				say(name, "Shop amélioré au niveau " .. tier .. " : " .. lane_slots(tier) ..
					" pile(s) de stock par article.")
			end
			return itemstack
		end
		show(clicker, pos)
		return itemstack
	end,

	-- Emplacements de vente : "fantômes" (l'objet posé n'est pas consommé,
	-- il sert de modèle : le nombre posé = quantité vendue).
	allow_metadata_inventory_put = function(pos, listname, index, stack, player)
		if not is_owner(pos, player) then return 0 end
		if listname == "sale" then
			set_sale(pos, index, stack, player)
			return 0
		elseif listname == "stock" and can_stock(pos, index, stack) then
			return stack:get_count()
		end
		return 0
	end,

	allow_metadata_inventory_take = function(pos, listname, index, stack, player)
		if not is_owner(pos, player) then return 0 end
		if listname == "sale" then
			clear_sale(pos, index, player)
			return 0
		end
		return stack:get_count()
	end,

	allow_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
		if not is_owner(pos, player) then return 0 end
		if from_list == "stock" and to_list == "stock" then
			local st = minetest.get_meta(pos):get_inventory():get_stack(from_list, from_index)
			if can_stock(pos, to_index, st) then return count end
		end
		return 0
	end,
})

minetest.register_craft({
	output = modname .. ":shop",
	recipe = {
		{"mcl_core:emerald", "group:wood", "mcl_core:emerald"},
		{"group:wood", "mcl_core:iron_ingot", "group:wood"},
		{"group:wood", "group:wood", "group:wood"},
	},
})

---------------------------------------------------------------------
-- Améliorations de stock
---------------------------------------------------------------------

for tier = 1, MAX_LEVEL do
	minetest.register_craftitem(modname .. ":upgrade_" .. tier, {
		description = "Amélioration de shop " .. ROMAN[tier],
		_tt_help = "Clic droit sur ton shop : " .. lane_slots(tier) .. " pile(s) de stock par article",
		inventory_image = "mcl_shop_upgrade_" .. tier .. ".png",
		stack_max = 16,
	})
end

minetest.register_craft({
	output = modname .. ":upgrade_1",
	recipe = {
		{"mcl_core:iron_ingot", "mcl_core:emerald", "mcl_core:iron_ingot"},
		{"mcl_core:emerald", "group:wood", "mcl_core:emerald"},
		{"mcl_core:iron_ingot", "mcl_core:emerald", "mcl_core:iron_ingot"},
	},
})
minetest.register_craft({
	output = modname .. ":upgrade_2",
	recipe = {
		{"mcl_core:gold_ingot", "mcl_core:emerald", "mcl_core:gold_ingot"},
		{"mcl_core:emerald", modname .. ":upgrade_1", "mcl_core:emerald"},
		{"mcl_core:gold_ingot", "mcl_core:emerald", "mcl_core:gold_ingot"},
	},
})
minetest.register_craft({
	output = modname .. ":upgrade_3",
	recipe = {
		{"mcl_core:diamond", "mcl_core:emeraldblock", "mcl_core:diamond"},
		{"mcl_core:emeraldblock", modname .. ":upgrade_2", "mcl_core:emeraldblock"},
		{"mcl_core:diamond", "mcl_core:emeraldblock", "mcl_core:diamond"},
	},
})
